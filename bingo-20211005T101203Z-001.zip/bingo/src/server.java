

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
class abc extends Thread{
    Socket sk;
    public abc(Socket sk){
        this.sk=sk;
    }
    public void run(){
        PrintStream cout=null;
        try {
            BufferedReader cin=new BufferedReader(new InputStreamReader(sk.getInputStream()));//create i/o stream for communicating to client
            cout = new PrintStream(sk.getOutputStream());
            BufferedReader stdin=new BufferedReader(new InputStreamReader(System.in));
            String s;
            while (true)
            {
                s=cin.readLine();//recieve from client
                if (s.equalsIgnoreCase("END"))
                {
                    cout.println("BYE");
                    break;
                }
                System. out.print("Client : "+s+"\n");
                System.out.print("Server : ");
                s=stdin.readLine();//send to client
                cout.println(s);//pass s onto the server
                
            }
//		ss.close();
// 		sk.close();
// 		cin.close();
//		cout.close();
// 		stdin.close();
        } catch (IOException ex) {
            Logger.getLogger(abc.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            cout.close();
        }
	}
    }

public class server {
    public static void connectionS() throws IOException {
       ServerSocket ss=new ServerSocket(2000);//open the server socket
		Socket sk;//wait for the client request
                System.out.println("hi");
		while(true){
                    sk=ss.accept();
                    abc t=new abc(sk);
                    t.start();
                }
		
}
}
