/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lenovo
 */

import java.io.*;

import java.io.IOException;
import java.util.Locale;
import javax.speech.*;
import javax.speech.synthesis.Synthesizer;
import javax.speech.synthesis.SynthesizerModeDesc;



class speak{

    public void speak2() 
    {
 
        try
        {
            // set property as Kevin Dictionary
            System.setProperty("freetts.voices",
                "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory"); 
                 
            // Register Engine
            Central.registerEngineCentral
                ("com.sun.speech.freetts.jsapi.FreeTTSEngineCentral");
 
            // Create a Synthesizer
            Synthesizer synthesizer =                                         
                Central.createSynthesizer(new SynthesizerModeDesc(Locale.US));     
     
            // Allocate synthesizer
            synthesizer.allocate();        
             
            // Resume Synthesizer
            synthesizer.resume();    
             
            // speaks the given text until queue is empty.
            synthesizer.speakPlainText("ITS NOT YOUR TURN", null);         
            synthesizer.waitEngineState(Synthesizer.QUEUE_EMPTY);
            
            // Deallocate the Synthesizer.
            synthesizer.deallocate();                                 
        } 
 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
}

