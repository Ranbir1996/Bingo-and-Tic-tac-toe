

import java.io.*;
import java.net.*;
import java.util.Scanner;
public class client {
    public  void connectionC () throws IOException {
         
         Socket sk=new Socket("localhost",2000);//create the socket object
             
		BufferedReader sin=new BufferedReader(new InputStreamReader(sk.getInputStream()));//create i/o stream for communicating to server
		PrintStream sout=new PrintStream(sk.getOutputStream());
		BufferedReader stdin=new BufferedReader(new InputStreamReader(System.in));
		String s;
		while (  true )
		{
			System.out.print("Client : ");
			s=stdin.readLine();//send to server
			sout.println(s);//passing s  onto the server
			s=sin.readLine();//recieve from server
			System.out.print("Server : "+s+"\n");
  			if ( s.equalsIgnoreCase("BYE") )
 			   break;
		}
		 sk.close();
		 sin.close();
		 sout.close();
 		stdin.close();
	}
}
